/*
 * config.h
 *
 *  Created on: 2019年3月21日
 *      Author: ppa
 */

#ifndef CONFIG_H_
#define CONFIG_H_
#include <gtk/gtk.h>
#include <stdlib.h>

int loadListData(char** list);


#endif /* CONFIG_H_ */
