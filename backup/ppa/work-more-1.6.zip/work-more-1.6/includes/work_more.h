

#ifndef WORK_MORE_H_
#define WORK_MORE_H_
#include <stdlib.h>
#include <iostream>
#include "gui/main_gui.h"

int loadConfig();



#endif /* WORK_MORE_H_ */
